# My First Project > 2026-10-02 5:26pm
https://universe.roboflow.com/mins-workspace-h1wpv/my-first-project-etgld

Provided by a Roboflow user
License: CC BY 4.0

